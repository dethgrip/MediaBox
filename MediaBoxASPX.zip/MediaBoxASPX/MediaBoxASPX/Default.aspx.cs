﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace MediaBoxASPX
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // NOTE: Several ways we can do this.
            // 1. Load/Parse xml string into an XDocument and build the html
            // 2. Use and XmlDocument and build the html
            // 3. Deserialize the xml into an object, then build the html
            StringBuilder sb = new StringBuilder();
            sb.Append("<table><tr>");
            sb.Append("<td>ProjectID</td>");
            sb.Append("<td>ProjectNumber</td>");
            sb.Append("<td>Submission Sub Type</td>");
            sb.Append("<td>SubmissionID</td>");
            sb.Append("<td>SubmissionNumber</td></tr>");

            DataModel dm = Converter.CreateDataModelObject();

            for (int i = 0; i <= dm.Proj.Count() - 1; i++)
            {
                if (dm.Proj[i].AllSubmissions != null)
                {
                    foreach (var obj in dm.Proj[i].AllSubmissions.Sub)
                    {
                        sb.Append("<tr><td>" + dm.Proj[i].ProjectID + "</td>");
                        sb.Append("<td>" + dm.Proj[i].ProjectNumber + "</td>");
                        sb.Append("<td>" + obj.Type + "</td>");
                        sb.Append("<td>" + obj.SubmissionID + "</td>");
                        sb.Append("<td>" + obj.SubmissionNumber + "</td></tr>");
                    }
                }
                else
                {
                    sb.Append("<tr><td>" + dm.Proj[i].ProjectID + "</td>");
                    sb.Append("<td>" + dm.Proj[i].ProjectNumber + "</td>");
                    sb.Append("<td colspan='3'>No Submissions</td></tr>");
                }
            }

            sb.Append("</table>");

            html.Text = sb.ToString();
        }
    }
}